#define ade 5
#define atra 5


void imprimaze();
int posivali(int x, int y);