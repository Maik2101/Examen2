 int posicionX;
 int posicionY;

void movimiento(char movi);
int valimovi(int x, int y);
int acabajuego();